## [1.0.6+1] - 2020/05/12
- bug fixed because of ListView default padding

## [1.0.6] - 2019/05/28
- trying to fix bug on scrolling

## [1.0.5] - 2019/05/28
- update time initialization

## [1.0.4] - 2019/05/13
- Bug fixing on snap scroll